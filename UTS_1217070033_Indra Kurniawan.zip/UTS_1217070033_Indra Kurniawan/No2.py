# Indra Kurniawan
# 1217070033

import cv2

gambar = cv2.imread('bean.jpeg')

tipe_data = gambar.dtype

print(f"Tipe data gambar: {tipe_data}")
